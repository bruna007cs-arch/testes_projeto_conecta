// Interações do Conecta Local: menu, filtros, favoritos, formulário e animações.
const botaoMenu=document.querySelector('.menu-alternar');
const menu=document.querySelector('.menu');
botaoMenu.addEventListener('click',()=>{const aberto=botaoMenu.getAttribute('aria-expanded')==='true';botaoMenu.setAttribute('aria-expanded',String(!aberto));botaoMenu.setAttribute('aria-label',aberto?'Abrir menu':'Fechar menu');menu.classList.toggle('aberto',!aberto)});
menu.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{menu.classList.remove('aberto');botaoMenu.setAttribute('aria-expanded','false');botaoMenu.setAttribute('aria-label','Abrir menu')}));

// Filtro de categorias com manipulação do DOM.
const filtros=document.querySelectorAll('.filtro');const cards=document.querySelectorAll('.card-negocio');const resultado=document.querySelector('#resultado-filtro');
filtros.forEach(botao=>botao.addEventListener('click',()=>{const categoria=botao.dataset.filtro;let total=0;filtros.forEach(item=>{const ativo=item===botao;item.classList.toggle('ativo',ativo);item.setAttribute('aria-pressed',String(ativo))});cards.forEach(card=>{const mostrar=categoria==='todos'||card.dataset.categoria===categoria;card.hidden=!mostrar;if(mostrar)total++});resultado.textContent=`Exibindo ${total} negócio(s)`}));

// Favoritos persistidos no navegador usando LocalStorage.
const chave='conectaLocalFavoritos';const contador=document.querySelector('#contador-favoritos');const botoes=document.querySelectorAll('.favoritar');
function obterFavoritos(){try{const lista=JSON.parse(localStorage.getItem(chave));return Array.isArray(lista)?lista:[]}catch(erro){return[]}}
let favoritos=obterFavoritos();
function atualizarFavoritos(){contador.textContent=favoritos.length;contador.setAttribute('aria-label',`${favoritos.length} favorito(s)`);botoes.forEach(botao=>{const salvo=favoritos.includes(botao.dataset.favorito);botao.setAttribute('aria-pressed',String(salvo));botao.querySelector('span').textContent=salvo?'♥':'♡';const nome=botao.closest('.card-negocio').querySelector('h3').textContent;botao.setAttribute('aria-label',`${salvo?'Remover':'Adicionar'} ${nome} ${salvo?'dos':'aos'} favoritos`)})}
botoes.forEach(botao=>botao.addEventListener('click',()=>{const id=botao.dataset.favorito;favoritos=favoritos.includes(id)?favoritos.filter(item=>item!==id):[...favoritos,id];localStorage.setItem(chave,JSON.stringify(favoritos));atualizarFavoritos()}));atualizarFavoritos();

// Formulário demonstrativo: validação nativa, sem envio para servidor.
const formulario=document.querySelector('#formContato');const aviso=document.querySelector('#mensagem-formulario');
formulario.addEventListener('submit',evento=>{evento.preventDefault();aviso.classList.remove('erro');if(!formulario.checkValidity()){formulario.reportValidity();return}const nome=document.querySelector('#nome').value.trim();aviso.textContent=`Obrigado, ${nome}! Os dados foram validados. Este protótipo não envia mensagens para um servidor.`;formulario.reset()});
formulario.addEventListener('input',()=>{aviso.textContent=''});

// Animação de entrada com IntersectionObserver; respeita a preferência de movimento reduzido via CSS.
const animados=document.querySelectorAll('.destaque-texto,.destaque-visual,.titulo-secao,.card-negocio,.sobre-conteudo,.contato-conteudo,.diferencial-conteudo');
if('IntersectionObserver'in window){const observador=new IntersectionObserver((entradas,obs)=>{entradas.forEach(entrada=>{if(entrada.isIntersecting){entrada.target.classList.add('visivel');obs.unobserve(entrada.target)}})},{threshold:.12});animados.forEach(elemento=>{elemento.classList.add('animar-entrada');observador.observe(elemento)})}
