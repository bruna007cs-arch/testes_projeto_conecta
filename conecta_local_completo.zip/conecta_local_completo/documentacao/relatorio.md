# Relatório do Projeto – Conecta Local

**Disciplina:** Desenvolvimento Front-end para Web  
**Projeto:** Portal de Comércio Local Sustentável  
**Ano:** 2026

## Objetivo
O Conecta Local é um protótipo de portal para apresentar pequenos negócios de uma comunidade e incentivar a valorização do comércio local. Os quatro estabelecimentos apresentados são fictícios e servem como conteúdo demonstrativo.

## Estrutura e tecnologias
A página utiliza HTML5 semântico, com `header`, `nav`, `main`, `section`, `article` e `footer`, títulos hierarquizados, links internos, imagens com textos alternativos e formulário. O CSS está separado em `css/estilo.css`, organizado por seções e comentários. O layout utiliza Flexbox e Grid, com regras para desktop, tablet e celular.

## Identidade visual e usabilidade
A identidade visual utiliza preto e grafite como base, textos claros e verde suave em detalhes. Os cards apresentam categoria, ilustração, descrição e link de interesse. Foram incluídos rótulos nos campos, foco visível para teclado, link para pular ao conteúdo e respeito à preferência do sistema por movimento reduzido.

## Interações e diferencial
O JavaScript controla o menu em telas menores, filtros por categoria, animações de entrada e validação demonstrativa do formulário. Como diferencial, o visitante pode favoritar negócios. A interface atualiza o contador e salva a lista no `LocalStorage`, mantendo os favoritos após atualizar a página no mesmo navegador.

## Limitações
Os estabelecimentos são fictícios e o formulário não envia dados para um servidor. O envio apenas demonstra a validação do navegador e exibe uma confirmação. Para uso real, seria necessária integração com backend, política de privacidade e informações verdadeiras dos empreendedores.

## Organização
`index.html` contém a estrutura; `css/estilo.css`, a apresentação; `js/script.js`, as interações; `img/`, as ilustrações SVG; e `documentacao/`, o relatório e o roteiro de testes.
