# Roteiro de testes – Conecta Local

| Nº | Teste | Procedimento | Resultado esperado |
|---|---|---|---|
| 1 | Navegação | Clicar nos links do menu | A página rola até a seção correta |
| 2 | Filtro geral | Selecionar Todos | Os quatro cards aparecem |
| 3 | Filtro por categoria | Selecionar cada categoria | Apenas o card correspondente aparece |
| 4 | Adicionar favorito | Clicar no coração de um card | Ícone muda e contador aumenta |
| 5 | Persistência | Atualizar a página após favoritar | Favorito continua salvo |
| 6 | Remover favorito | Clicar novamente no coração | Ícone volta e contador diminui |
| 7 | Campos obrigatórios | Enviar formulário vazio | Navegador impede o envio |
| 8 | E-mail inválido | Digitar e-mail fora do formato | Navegador solicita correção |
| 9 | Envio demonstrativo | Preencher os campos corretamente | Mensagem de confirmação aparece |
| 10 | Menu mobile | Abrir e fechar o menu no celular | Menu funciona e navega às seções |
| 11 | Responsividade | Testar desktop, tablet e celular | Conteúdo se reorganiza sem rolagem horizontal |
| 12 | Acessibilidade básica | Navegar com Tab e verificar imagens | Foco visível e textos alternativos presentes |
