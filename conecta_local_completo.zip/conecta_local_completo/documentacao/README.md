# Conecta Local

Portal demonstrativo de comércio local sustentável.

## Como executar
1. Extraia o ZIP.
2. Abra `index.html` em um navegador atualizado.
3. Não é necessário instalar dependências.

## Estrutura
- `index.html`: estrutura semântica.
- `css/estilo.css`: identidade visual, layout e responsividade.
- `js/script.js`: menu, filtros, favoritos, LocalStorage, formulário e animações.
- `img/`: ilustrações SVG e ícone.
- `documentacao/`: relatório e roteiro de testes.

## Observações
Os negócios são fictícios. O formulário é demonstrativo e não envia dados para servidor. Os favoritos são armazenados no navegador do usuário.
