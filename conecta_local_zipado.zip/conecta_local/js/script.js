// Animação suave dos elementos quando aparecem na tela.
const elementosAnimados = document.querySelectorAll(
  '.destaque-texto, .destaque-visual, .titulo-secao, .card-negocio, .sobre-conteudo'
);

elementosAnimados.forEach((elemento) => {
  elemento.classList.add('animar-entrada');
});

const observador = new IntersectionObserver((entradas) => {
  entradas.forEach((entrada) => {
    if (entrada.isIntersecting) {
      entrada.target.classList.add('visivel');
      observador.unobserve(entrada.target);
    }
  });
}, { threshold: 0.12 });

elementosAnimados.forEach((elemento) => observador.observe(elemento));
